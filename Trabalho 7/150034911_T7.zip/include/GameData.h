#pragma once

#ifndef GAMEDATA_H
#define GAMEDATA_H

class GameData {
public:
	static bool playerVictory;
};

#endif // GAMEDATA_H
