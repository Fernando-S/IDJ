#include "GameData.h"

bool GameData::playerVictory = false;