/*###############################################################################
# Universidade de Brasilia														#
#	Trabalho 5 da disciplina de Introducao ao Desenvolvimento de Jogos			#
#	Aluno: Fernando Sobral Nobrega				Matricula: 15/0034911			#
#	OS: Windows 10 Pro															#
#	IDE: Visual Studio 2017														#
###############################################################################*/


#include "Game.h"

int main(int argc, char* argv[]) {
	Game::GetInstance().Run();
	return 0;
}